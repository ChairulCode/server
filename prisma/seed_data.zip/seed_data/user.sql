BEGIN;

-- ====================================================
-- 1. ROLE (PK Int)
-- ====================================================

INSERT INTO "role" (role_id, nama_role) VALUES
(1, 'Super Administrator'),
(2, 'Kepala Sekolah PG-TK'),
(3, 'Kepala Sekolah SD'),
(4, 'Kepala Sekolah SMP'), 
(5, 'Kepala Sekolah SMA')
ON CONFLICT (role_id) DO NOTHING;

-- ====================================================
-- 2. PERMISSION (PK Int AUTOINCREMENT) - Ditambahkan nilai 'grup'
-- ====================================================

INSERT INTO "permission" (permission_id, nama_permission, grup) VALUES
(1, 'akses_dashboard', 'dashboard'),
(2, 'kelola_user', 'user'),
(3, 'kelola_user_roles', 'user_roles'),
(4, 'kelola_user_permissions', 'user_roles_permissions'),
(5, 'kelola_siswa', 'siswa'),
(6, 'kelola_prestasi', 'prestasi'),
(7, 'kelola_kegiatan', 'kegiatan'),
(8, 'kelola_pengumuman', 'pengumuman'),
(9, 'kelola_carousel', 'carousel'),
(10, 'kelola_foto', 'foto'),
(11,'kelola_sosmed','sosmed')
ON CONFLICT (permission_id) DO NOTHING;

-- Mengatur ulang sequence untuk permission_id agar mulai dari MAX(permission_id) + 1
SELECT setval(pg_get_serial_sequence('permission', 'permission_id'), (SELECT COALESCE(MAX(permission_id), 1) FROM "permission"), true);

-- ====================================================
-- 3. ROLE_PERMISSION (Tabel Relasi Many-to-Many)
-- ====================================================

INSERT INTO "role_permission" (role_id, permission_id) VALUES
-- Admin (Role ID: 1): Semua (ID 1-8)
(1, 1), (1, 2), (1, 3), (1, 4), (1, 5), (1, 6), (1, 7), (1, 8), (1, 9), (1, 10), (1, 11),
-- Kepala Sekolah PG-TK
(2, 1), (2, 5), (2, 6),(2, 7), (2, 8), (2 ,9),
-- Kepala Sekolah SD
(3, 1), (3, 5), (3, 6), (3, 7), (3, 8), (3 ,9),
-- Kepala Sekolah SMP
(4, 1), (4, 5), (4, 6), (4, 7), (4, 8), (4 ,9),
-- Kepala Sekolah SMA
(5, 1), (5, 5), (5, 6), (5, 7), (5, 8), (5 ,9)
ON CONFLICT (role_id, permission_id) DO NOTHING;


INSERT INTO "users" (user_id,username,email, password_hash,nama_lengkap, role_id) VALUES
(CAST('a3a02f83-0d81-48c6-9688-efc5b8c702f2' AS UUID),'Super Administrator','athayanaufalbrasta@gmail.com','$2b$10$vDUg6GyqZ45U4.mZzlXOPOZFQkqGikhZPqhJD7bE3lh4MTXCeA6Ii','Super Administrator',1),
(CAST('243ccbaf-d6eb-46f7-b69b-189432a8e219' AS UUID),'Kepala Sekolah PG-TK','tes1@gmail.com','$2b$10$xkHvQLPKw5L7qz5BLRYU1OUvefU0jdBROy1fXC.ofon1oRw4uiQJu','Kepala Sekolah ',2),
(CAST('6d5f661e-c943-4cda-90ff-3f361b395d95' AS UUID),'Kepala Sekolah SD','tes2@gmail.com','$2b$10$xkHvQLPKw5L7qz5BLRYU1OUvefU0jdBROy1fXC.ofon1oRw4uiQJu','Kepala Sekolah ',3),
(CAST('4cd6e5df-de08-4ab9-a91e-64fbf7f071d6' AS UUID),'Kepala Sekolah SMP','tes3@gmail.com','$2b$10$xkHvQLPKw5L7qz5BLRYU1OUvefU0jdBROy1fXC.ofon1oRw4uiQJu','Kepala Sekolah ',4),
(CAST('fc21f671-288a-48c2-85c0-02a67fbf9261' AS UUID),'Kepala Sekolah SMA','tes4@gmail.com','$2b$10$xkHvQLPKw5L7qz5BLRYU1OUvefU0jdBROy1fXC.ofon1oRw4uiQJu','Kepala Sekolah ',5);

COMMIT;