BEGIN;

INSERT INTO "pengumuman" (
    pengumuman_id,
    judul,
    deskripsi,
    konten,
    tanggal_publikasi,
    penulis_user_id
) 
VALUES
(
    '30000000-0001-4000-8000-000000000001', -- Pengumuman ID 1
    'Jadwal Ujian Semester Ganjil',
    'Ujian semester akan dilaksanakan pada tanggal 5 - 12 Januari 2025. Persiapkan diri Anda!',
    'Konten lengkap berisi daftar mata pelajaran dan ruang ujian untuk semua kelas.',
    '2025-01-05 08:00:00', -- Diberikan waktu agar sesuai format Timestamp(3)
    'a3a02f83-0d81-48c6-9688-efc5b8c702f2'
),
(
    '30000000-0001-4000-8000-000000000002', -- Pengumuman ID 2
    'Lomba Kebersihan Kelas SMP',
    'Lomba kebersihan antar kelas khusus jenjang SMP akan dimulai. Jaga kebersihan kelas Anda!',
    'Kriteria penilaian lomba meliputi kerapian meja, kebersihan lantai, dan dekorasi.',
    '2024-11-20 08:00:00',
    'a3a02f83-0d81-48c6-9688-efc5b8c702f2'
),
(
    '30000000-0001-4000-8000-000000000003', -- Pengumuman ID 3
    'Libur Hari Raya Idul Adha',
    'Sekolah libur mulai tanggal 10 Juli 2025. Masuk kembali tanggal 15 Juli 2025.',
    'Mohon diperhatikan agar tidak ada kegiatan di lingkungan sekolah selama masa libur. Selamat berlibur.',
    '2025-07-10 08:00:00',
    'a3a02f83-0d81-48c6-9688-efc5b8c702f2'
)

ON CONFLICT (pengumuman_id) DO NOTHING;

COMMIT;

BEGIN;

INSERT INTO "pengumuman_jenjang" (pengumuman_id, jenjang_id) VALUES
-- Pengumuman ID 1 (Jadwal Ujian Semester Ganjil) -> Semua Jenjang
('30000000-0001-4000-8000-000000000001', 'b1b820d5-2714-41ee-a8e2-4da7714da164'), -- PGTK
('30000000-0001-4000-8000-000000000001', 'f8d1bb69-4839-4b13-977e-d21671e546f5'), -- SD
('30000000-0001-4000-8000-000000000001', 'bbbd1c32-72e8-4710-b209-e1503a9250eb'), -- SMP
('30000000-0001-4000-8000-000000000001', '0c09118b-be66-4f04-aaf0-a15e77aa870a'), -- SMA

-- Pengumuman ID 2 (Lomba Kebersihan Kelas SMP) -> Khusus SMP
('30000000-0001-4000-8000-000000000002', 'bbbd1c32-72e8-4710-b209-e1503a9250eb'), -- SMP

-- Pengumuman ID 3 (Libur Hari Raya Idul Adha) -> Semua Jenjang (Umum)
('30000000-0001-4000-8000-000000000003', 'b1b820d5-2714-41ee-a8e2-4da7714da164'), -- PGTK
('30000000-0001-4000-8000-000000000003', 'f8d1bb69-4839-4b13-977e-d21671e546f5'), -- SD
('30000000-0001-4000-8000-000000000003', 'bbbd1c32-72e8-4710-b209-e1503a9250eb'), -- SMP
('30000000-0001-4000-8000-000000000003', '0c09118b-be66-4f04-aaf0-a15e77aa870a')  -- SMA

ON CONFLICT DO NOTHING;

COMMIT;