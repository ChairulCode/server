BEGIN;

INSERT INTO jenjang(jenjang_id, nama_jenjang, kode_jenjang) VALUES
('b1b820d5-2714-41ee-a8e2-4da7714da164','PG-TK','PG-TK'),
('f8d1bb69-4839-4b13-977e-d21671e546f5','SD','SD'),
('bbbd1c32-72e8-4710-b209-e1503a9250eb','SMP','SMP'),
('0c09118b-be66-4f04-aaf0-a15e77aa870a','SMA','SMA') 
ON CONFLICT DO NOTHING;

COMMIT;