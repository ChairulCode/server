BEGIN;

INSERT INTO "carousel" (
    carousel_id,
    judul, 
    urutan, 
    konten, 
    path_gambar, 
    tanggal_publikasi, 
    is_published, 
    is_featured,
    jenjang_id,             -- Foreign Key ke Jenjang (1:M)
    penulis_user_id,
    editor_user_id
)
VALUES
-- 1. Promosi PSB (Umum/Semua Jenjang)
(
    '40000000-0001-4000-8000-000000000001',
    'Penerimaan Siswa Baru Tahun Ajaran 2026/2027', 
    1, 
    'Ayo segera daftar! Dapatkan beasiswa khusus pendaftar gelombang pertama.', 
    'carousels/slide1.jpg', 
    '2025-12-14 09:00:00', 
    TRUE, 
    TRUE,
    NULL, -- NULL berarti berlaku untuk semua jenjang
    'a3a02f83-0d81-48c6-9688-efc5b8c702f2',
    NULL
),
-- 2. Prestasi Terbaru (SMA)
(
    '40000000-0001-4000-8000-000000000002',
    'Juara I Olimpiade Sains Nasional - Jenjang SMA', 
    2, 
    'Selamat kepada tim sains SMA yang telah mengharumkan nama sekolah di tingkat nasional.', 
    'carousels/slide2.jpg', 
    '2025-12-10 12:00:00', 
    TRUE, 
    TRUE,
    '0c09118b-be66-4f04-aaf0-a15e77aa870a', -- ID SMA
    'a3a02f83-0d81-48c6-9688-efc5b8c702f2',
    NULL
),
-- 3. Kegiatan Sekolah (SMP)
(
    '40000000-0001-4000-8000-000000000003',
    'Field Trip ke Museum Perjuangan - SMP', 
    3, 
    'Siswa kelas 8 SMP belajar sejarah secara langsung di Museum Kota Medan.', 
    'carousels/slide3.jpg', 
    '2025-11-25 15:30:00', 
    TRUE, 
    FALSE,
    'bbbd1c32-72e8-4710-b209-e1503a9250eb', -- ID SMP
    'a3a02f83-0d81-48c6-9688-efc5b8c702f2',
    NULL
),
-- 4. Pengumuman Libur (Umum)
(
    '40000000-0001-4000-8000-000000000004',
    'Perhatian! Libur Akhir Semester', 
    4, 
    'Kegiatan belajar mengajar akan diliburkan mulai 20 Desember hingga 2 Januari.', 
    'carousels/slide4.jpg', 
    '2025-12-01 07:00:00', 
    TRUE, 
    FALSE,
    NULL,
    'a3a02f83-0d81-48c6-9688-efc5b8c702f2',
    NULL
),
-- 5. Prestasi Seni (PGTK)
(
    '40000000-0001-4000-8000-000000000005',
    'Juara Mewarnai Tingkat Kota - TK', 
    5, 
    'Selamat kepada Ananda Budi dari TK B yang meraih juara 1 lomba mewarnai.', 
    'carousels/slide5.jpg', 
    '2025-11-15 11:00:00', 
    TRUE, 
    TRUE,
    'b1b820d5-2714-41ee-a8e2-4da7714da164', -- ID PGTK
    'a3a02f83-0d81-48c6-9688-efc5b8c702f2',
    NULL
),
-- 6. Promo Ekstrakurikuler (SD)
(
    '40000000-0001-4000-8000-000000000006',
    'Pendaftaran Ekstrakurikuler Futsal Dibuka!', 
    6, 
    'Khusus siswa SD kelas 4-6, segera daftarkan diri Anda dan tunjukkan bakat terbaik Anda!', 
    'carousels/slide1.jpg', 
    '2025-10-01 13:00:00', 
    TRUE, 
    FALSE,
    'f8d1bb69-4839-4b13-977e-d21671e546f5', -- ID SD
    'a3a02f83-0d81-48c6-9688-efc5b8c702f2',
    NULL
),
-- 7. Peringatan Penting (UMUM, Tidak Featured)
(
    '40000000-0001-4000-8000-000000000007',
    'Waspada Penipuan Mengatasnamakan Sekolah', 
    7, 
    'Mohon abaikan permintaan transfer dana yang mencurigakan. Informasi resmi hanya melalui kanal ini.', 
    'carousels/slide.jpg', 
    '2025-10-05 10:00:00', 
    TRUE, 
    FALSE,
    NULL,
    'a3a02f83-0d81-48c6-9688-efc5b8c702f2',
    NULL
),
-- 8. Penggalangan Dana (UMUM, Featured)
(
    '40000000-0001-4000-8000-000000000008',
    'Ayo Bantu Korban Bencana Alam!', 
    8, 
    'Open donasi untuk korban banjir di wilayah Deli Serdang. Bantuan disalurkan hingga akhir bulan.', 
    'carousels/slide6.jpg', 
    '2025-09-20 16:00:00', 
    TRUE, 
    TRUE,
    NULL,
    'a3a02f83-0d81-48c6-9688-efc5b8c702f2',
    NULL
),
-- 9. Lomba Internal (SMP)
(
    '40000000-0001-4000-8000-000000000009',
    'Kompetisi Debat Bahasa Indonesia - SMP', 
    9, 
    'Pendaftaran dibuka! Tingkatkan kemampuan berpikir kritis dan retorika Anda.', 
    'carousels/slide1.jpg', 
    '2025-09-15 08:30:00', 
    TRUE, 
    FALSE,
    'bbbd1c32-72e8-4710-b209-e1503a9250eb', -- ID SMP
    'a3a02f83-0d81-48c6-9688-efc5b8c702f2',
    NULL
),
-- 10. Pengumuman Kelulusan (SMA, tidak diterbitkan dulu)
(
    '40000000-0001-4000-8000-000000000010',
    'Pengumuman Hasil UN dan Kelulusan Angkatan 2026', 
    10, 
    'Detail hasil UN dan pengumuman kelulusan akan disampaikan melalui website resmi pada tanggal 10 Mei 2026.', 
    'carousels/slide2.jpg', 
    '2026-05-10 00:00:00', 
    FALSE, -- TIDAK DITERBITKAN
    FALSE,
    '0c09118b-be66-4f04-aaf0-a15e77aa870a', -- ID SMA
    'a3a02f83-0d81-48c6-9688-efc5b8c702f2',
    NULL
)

ON CONFLICT (carousel_id) DO NOTHING;

COMMIT;