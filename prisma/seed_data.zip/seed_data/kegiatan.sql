BEGIN;

INSERT INTO "kegiatan" (
    kegiatan_id,
    judul, 
    deskripsi, 
    konten, 
    path_gambar, 
    tanggal_publikasi,
    penulis_user_id
)
VALUES
-- Kegiatan 1: Lomba Cipta Boga (UMUM - SMA)
('20000000-0001-4000-8000-000000000001', 'Kegiatan Lomba Cipta Boga', 'Kompetisi memasak dan kreasi kuliner antar siswa untuk mengembangkan kreativitas dan minat di bidang tata boga.', 'Kompetisi memasak dan kreasi kuliner antar siswa untuk mengembangkan kreativitas dan minat di bidang tata boga.', 'activities/boga a.jpg', '2024-10-20 09:00:00', 'a3a02f83-0d81-48c6-9688-efc5b8c702f2'),
-- Kegiatan 2: Bazar HUT (UMUM)
('20000000-0001-4000-8000-000000000002', 'Kegiatan Bazar Menyambut HUT ke 60 Perguruan WR Supratman', 'Pameran produk siswa dan UMKM lokal dalam rangka perayaan ulang tahun perguruan.', 'Pameran produk siswa dan UMKM lokal dalam rangka perayaan ulang tahun perguruan.', 'activities/bazar 2020.jpg', '2024-11-01 08:00:00', 'a3a02f83-0d81-48c6-9688-efc5b8c702f2'),
-- Kegiatan 3: Lomba TIK Virtual (UMUM)
('20000000-0001-4000-8000-000000000003', 'Lomba TIK Virtual Menyambut Hari Pendidikan Nasional 2021', 'Ajang kompetisi di bidang Teknologi Informasi dan Komunikasi yang diadakan secara daring.', 'Ajang kompetisi di bidang Teknologi Informasi dan Komunikasi yang diadakan secara daring.', 'activities/juara tik virtual 2021 copy copy.jpg', '2021-05-02 10:00:00', 'a3a02f83-0d81-48c6-9688-efc5b8c702f2'),
-- Kegiatan 4: PSB (UMUM)
('20000000-0001-4000-8000-000000000004', 'Penerimaan Siswa-Siswi Baru TP 2021-2022 Onsite dan Online', 'Sosialisasi dan proses pendaftaran siswa baru untuk tahun pelajaran 2021-2022 secara hybrid.', 'Sosialisasi dan proses pendaftaran siswa baru untuk tahun pelajaran 2021-2022 secara hybrid.', 'activities/brosur gabungan 2021 web.jpg', '2021-04-01 08:00:00', 'a3a02f83-0d81-48c6-9688-efc5b8c702f2'),
-- Kegiatan 5: Lomba TIK SMA
('20000000-0001-4000-8000-000000000005', 'Kegiatan Lomba TIK SMA WR Supratman 1 Tahun 2022', 'Lomba coding, desain grafis, dan pengembangan aplikasi sederhana yang diikuti oleh siswa SMA.', 'Lomba coding, desain grafis, dan pengembangan aplikasi sederhana yang diikuti oleh siswa SMA.', 'activities/lomba tik.jpg', '2022-09-15 09:00:00', 'a3a02f83-0d81-48c6-9688-efc5b8c702f2'),
-- Kegiatan 6: Studi Wisata Brastagi (UMUM)
('20000000-0001-4000-8000-000000000006', 'Kegiatan Studi Wisata di Brastagi', 'Perjalanan edukatif dan rekreasi ke objek-objek wisata dan budaya di dataran tinggi Brastagi.', 'Perjalanan edukatif dan rekreasi ke objek-objek wisata dan budaya di dataran tinggi Brastagi.', 'activities/brastagi 1.jpg', '2025-05-20 07:00:00', 'a3a02f83-0d81-48c6-9688-efc5b8c702f2'),
-- Kegiatan 7: Penguatan Prakarya (UMUM)
('20000000-0001-4000-8000-000000000007', 'Kegiatan Penguatan Mapel Prakaya dan Kewirausahaan', 'Workshop praktis untuk meningkatkan keterampilan siswa dalam prakarya dan memulai usaha kecil.', 'Workshop praktis untuk meningkatkan keterampilan siswa dalam prakarya dan memulai usaha kecil.', 'activities/kuliner 1.jpg', '2023-03-08 10:00:00', 'a3a02f83-0d81-48c6-9688-efc5b8c702f2'),
-- Kegiatan 8: Donor Darah (UMUM)
('20000000-0001-4000-8000-000000000008', 'Kegiatan Donor Darah Maret 2023', 'Aksi sosial kemanusiaan rutin bekerjasama dengan Palang Merah Indonesia (PMI).', 'Aksi sosial kemanusiaan rutin bekerjasama dengan Palang Merah Indonesia (PMI).', 'activities/donor darah 3.jpg', '2023-03-15 08:00:00', 'a3a02f83-0d81-48c6-9688-efc5b8c702f2'),
-- Kegiatan 9: Tanoto Youth Scholars Gathering (SMA)
('20000000-0001-4000-8000-000000000009', 'Mengikuti Kegiatan Tanoto Youth Scholars Gathering', 'Pertemuan beasiswa dan pengembangan diri yang diselenggarakan oleh Tanoto Foundation.', 'Pertemuan beasiswa dan pengembangan diri yang diselenggarakan oleh Tanoto Foundation.', 'activities/tanoto 1.jpg', '2024-01-20 09:00:00', 'a3a02f83-0d81-48c6-9688-efc5b8c702f2'),
-- Kegiatan 10: Seminar HPV (SMA)
('20000000-0001-4000-8000-000000000010', 'Kegiatan Seminar Kenali dan Cegah HPV Untuk Siswi SMA', 'Edukasi kesehatan reproduksi dan pencegahan HPV untuk meningkatkan kesadaran siswi.', 'Edukasi kesehatan reproduksi dan pencegahan HPV untuk meningkatkan kesadaran siswi.', 'activities/hpv a.jpg', '2024-02-14 13:00:00', 'a3a02f83-0d81-48c6-9688-efc5b8c702f2'),
-- Kegiatan 11: Seminar Bisnis (SMA)
('20000000-0001-4000-8000-000000000011', 'Seminar All Businesses are Service Business dan Trend in Digital Era', 'Pemaparan tren bisnis dan digitalisasi serta pentingnya orientasi layanan di era digital.', 'Pemaparan tren bisnis dan digitalisasi serta pentingnya orientasi layanan di era digital.', 'activities/binus1a.jpg', '2024-11-25 09:30:00', 'a3a02f83-0d81-48c6-9688-efc5b8c702f2'),
-- Kegiatan 12: Berbagi Takjil (UMUM)
('20000000-0001-4000-8000-000000000012', 'Kegiatan Berbagi Takjil dan Buka Puasa Bersama', 'Kegiatan amal berbagi takjil dan berbuka puasa bersama di bulan Ramadhan.', 'Kegiatan amal berbagi takjil dan berbuka puasa bersama di bulan Ramadhan.', 'activities/takjil 1.jpg', '2024-03-28 17:00:00', 'a3a02f83-0d81-48c6-9688-efc5b8c702f2'),
-- Kegiatan 13: Outbound Kls 12 (SMA)
('20000000-0001-4000-8000-000000000013', 'Kegiatan Outbound Training Untuk Siswa Kelas 12', 'Pelatihan mental, kerjasama tim, dan kepemimpinan untuk persiapan kelulusan siswa kelas 12.', 'Pelatihan mental, kerjasama tim, dan kepemimpinan untuk persiapan kelulusan siswa kelas 12.', 'activities/outbound 1.jpg', '2025-06-10 07:00:00', 'a3a02f83-0d81-48c6-9688-efc5b8c702f2'),
-- Kegiatan 14: Waisak (UMUM)
('20000000-0001-4000-8000-000000000014', 'Perayaan Tri Suci Waisak 2567 BE / 2023', 'Peringatan hari raya agama Buddha untuk menumbuhkan nilai-nilai spiritual dan keagamaan.', 'Peringatan hari raya agama Buddha untuk menumbuhkan nilai-nilai spiritual dan keagamaan.', 'activities/waisak2023a.jpg', '2023-06-04 18:00:00', 'a3a02f83-0d81-48c6-9688-efc5b8c702f2'),
-- Kegiatan 15: Best Project Kls X (SMA)
('20000000-0001-4000-8000-000000000015', 'Best Project IT : Membuat Aplikasi Program Pembelajaran dengan APP Inventor oleh siswa kelas X', 'Pameran hasil proyek siswa kelas X dalam pengembangan aplikasi mobile menggunakan App Inventor.', 'Pameran hasil proyek siswa kelas X dalam pengembangan aplikasi mobile menggunakan App Inventor.', 'activities/projectmei1.png', '2024-05-10 14:00:00', 'a3a02f83-0d81-48c6-9688-efc5b8c702f2'),
-- Kegiatan 16: Best Project Kls XI (SMA)
('20000000-0001-4000-8000-000000000016', 'Best Project ITK : Membuat Game Edukasi Dengan App Inventor oleh kelas XI', 'Pameran hasil karya siswa kelas XI berupa game edukasi yang dibangun dengan App Inventor.', 'Pameran hasil karya siswa kelas XI berupa game edukasi yang dibangun dengan App Inventor.', 'activities/project31meia.png', '2024-05-31 14:00:00', 'a3a02f83-0d81-48c6-9688-efc5b8c702f2'),
-- Kegiatan 17: Seminar Cybercrime (UMUM)
('20000000-0001-4000-8000-000000000017', 'Kegiatan Seminar Untuk Siswa Dengan Judul : "Cybercrime & Digital Footprint"', 'Edukasi keamanan siber dan cara mengelola jejak digital secara aman dan bertanggung jawab.', 'Edukasi keamanan siber dan cara mengelola jejak digital secara aman dan bertanggung jawab.', 'activities/cybera.png', '2024-08-18 10:00:00', 'a3a02f83-0d81-48c6-9688-efc5b8c702f2'),
-- Kegiatan 18: Kunjungan RGE Career (SMA)
('20000000-0001-4000-8000-000000000018', 'Kunjungan Belajar ke The Heritage & RGE Career Center', 'Kunjungan industri untuk orientasi karir dan melihat peluang di sektor industri.', 'Kunjungan industri untuk orientasi karir dan melihat peluang di sektor industri.', 'activities/heri 3.jpg', '2023-11-05 08:00:00', 'a3a02f83-0d81-48c6-9688-efc5b8c702f2'),
-- Kegiatan 19: Donor Darah Tzu Chi (UMUM)
('20000000-0001-4000-8000-000000000019', 'Kegiatan Donor Darah bersama Tzu Chi', 'Aksi kemanusiaan donor darah bekerjasama dengan Yayasan Buddha Tzu Chi.', 'Aksi kemanusiaan donor darah bekerjasama dengan Yayasan Buddha Tzu Chi.', 'activities/donor darah 15okt23 a.png', '2023-10-15 08:00:00', 'a3a02f83-0d81-48c6-9688-efc5b8c702f2'),
-- Kegiatan 20: Perekaman E-KTP (SMA)
('20000000-0001-4000-8000-000000000020', 'Perekaman E-KTP Gratis Untuk Siswa-Siswi SMA WRS 1', 'Fasilitasi perekaman KTP elektronik bagi siswa yang telah memenuhi syarat usia bekerja sama dengan Dukcapil.', 'Fasilitasi perekaman KTP elektronik bagi siswa yang telah memenuhi syarat usia bekerja sama dengan Dukcapil.', 'activities/ktp a.png', '2024-07-22 09:00:00', 'a3a02f83-0d81-48c6-9688-efc5b8c702f2'),
-- Kegiatan 21: Seminar Keuangan (UMUM)
('20000000-0001-4000-8000-000000000021', 'Kegiatan Seminar Inklusi Keuangan', 'Edukasi tentang pentingnya literasi dan inklusi keuangan untuk masa depan yang lebih terencana.', 'Edukasi tentang pentingnya literasi dan inklusi keuangan untuk masa depan yang lebih terencana.', 'activities/bca a.jpg', '2024-04-05 10:00:00', 'a3a02f83-0d81-48c6-9688-efc5b8c702f2'),
-- Kegiatan 22: Talent Mapping (UMUM/SMA)
('20000000-0001-4000-8000-000000000022', 'Kegiatan Talent Mapping 2022', 'Tes dan analisis minat bakat siswa untuk membantu penentuan jurusan kuliah dan karir.', 'Tes dan analisis minat bakat siswa untuk membantu penentuan jurusan kuliah dan karir.', 'activities/talent mapping 2022.jpg', '2022-07-10 09:00:00', 'a3a02f83-0d81-48c6-9688-efc5b8c702f2'),
-- Kegiatan 23: Bakti Sosial 2022 (UMUM)
('20000000-0001-4000-8000-000000000023', 'Perguruan WR Supratman 1 Mengadakan Bakti Sosial 2022', 'Kegiatan amal untuk membantu masyarakat kurang mampu menjelang akhir tahun.', 'Kegiatan amal untuk membantu masyarakat kurang mampu menjelang akhir tahun.', 'activities/doc1 2.jpg', '2022-12-20 08:00:00', 'a3a02f83-0d81-48c6-9688-efc5b8c702f2'),
-- Kegiatan 24: Jalan Sehat (UMUM)
('20000000-0001-4000-8000-000000000024', 'Jalan Sehat Perguruan WR Supratman 1', 'Olahraga bersama dalam rangka peringatan HUT Kemerdekaan Republik Indonesia.', 'Olahraga bersama dalam rangka peringatan HUT Kemerdekaan Republik Indonesia.', 'activities/start jalan sehat.jpg', '2023-08-17 07:00:00', 'a3a02f83-0d81-48c6-9688-efc5b8c702f2'),
-- Kegiatan 25: Business Plan UNPRI (SMA)
('20000000-0001-4000-8000-000000000025', 'Siswa SMA WRS 1 Juara I Lomba Business Plan UNPRI 2015', 'Prestasi siswa dalam kompetisi rencana bisnis tingkat universitas.', 'Prestasi siswa dalam kompetisi rencana bisnis tingkat universitas.', 'activities/dsc_0233 copy.jpg', '2015-11-20 08:00:00', 'a3a02f83-0d81-48c6-9688-efc5b8c702f2'),
-- Kegiatan 26: Kunjungan Indofood & ASW (UMUM)
('20000000-0001-4000-8000-000000000026', 'Kunjungan Edukatif ke PT Indofood dan PT ASW', 'Kunjungan industri untuk melihat langsung proses produksi makanan dan minuman.', 'Kunjungan industri untuk melihat langsung proses produksi makanan dan minuman.', 'activities/104252 copy.jpg', '2017-03-01 07:30:00', 'a3a02f83-0d81-48c6-9688-efc5b8c702f2'),
-- Kegiatan 27: Malam Kenangan (SMP/SMA)
('20000000-0001-4000-8000-000000000027', 'Malam Sejuta Kenangan SMP-SMA WR Supratman 1 & 2', 'Acara perpisahan dan malam kenangan siswa tingkat akhir SMP dan SMA.', 'Acara perpisahan dan malam kenangan siswa tingkat akhir SMP dan SMA.', 'activities/dsc_0021 copy.jpg', '2018-05-25 18:30:00', 'a3a02f83-0d81-48c6-9688-efc5b8c702f2'),
-- Kegiatan 28: Motivasi Motivator Termuda (UMUM)
('20000000-0001-4000-8000-000000000028', 'Motivasi oleh Motivator Termuda Indonesia', 'Sesi inspiratif untuk menumbuhkan semangat belajar dan meraih cita-cita.', 'Sesi inspiratif untuk menumbuhkan semangat belajar dan meraih cita-cita.', 'activities/dsc_7230 copy.jpg', '2018-09-10 10:00:00', 'a3a02f83-0d81-48c6-9688-efc5b8c702f2'),
-- Kegiatan 29: Kunjungan Harian Analisa (UMUM)
('20000000-0001-4000-8000-000000000029', 'Kunjungan Siswa WR Supratman 1 ke Harian Analisa', 'Kunjungan ke media massa untuk memahami dunia jurnalistik dan penerbitan.', 'Kunjungan ke media massa untuk memahami dunia jurnalistik dan penerbitan.', 'activities/kunjungan murid berprestasi sd smp sma ke harian analisa tgl 27 september 2016 copy.jpg', '2016-09-27 09:00:00', 'a3a02f83-0d81-48c6-9688-efc5b8c702f2'),
-- Kegiatan 30: Studi Ekskursi BI (UMUM)
('20000000-0001-4000-8000-000000000030', 'Studi Ekskursi Siswa WR Supratman 1 ke Bank Indonesia Medan', 'Kunjungan belajar tentang sistem moneter, perbankan, dan peran Bank Indonesia.', 'Kunjungan belajar tentang sistem moneter, perbankan, dan peran Bank Indonesia.', 'activities/20161004_104744 copy.jpg', '2016-10-04 08:30:00', 'a3a02f83-0d81-48c6-9688-efc5b8c702f2'),
-- Kegiatan 31: Lomba Gerak Jalan (UMUM)
('20000000-0001-4000-8000-000000000031', 'Lomba Gerak Jalan Menyambut HUT ke 72 RI', 'Kompetisi baris-berbaris antar kelas dalam rangka perayaan hari kemerdekaan.', 'Kompetisi baris-berbaris antar kelas dalam rangka perayaan hari kemerdekaan.', 'activities/dsc04180 copy.jpg', '2017-08-16 08:00:00', 'a3a02f83-0d81-48c6-9688-efc5b8c702f2'),
-- Kegiatan 32: Parade Drumband (UMUM)
('20000000-0001-4000-8000-000000000032', 'Parade Drumband & Jalan Sehat Menyambut HUT ke 73 RI', 'Perayaan HUT RI dengan parade drumband dan kegiatan jalan sehat.', 'Perayaan HUT RI dengan parade drumband dan kegiatan jalan sehat.', 'activities/dsc04558 copy.jpg', '2018-08-16 07:00:00', 'a3a02f83-0d81-48c6-9688-efc5b8c702f2'),
-- Kegiatan 33: Drumband Lapangan Merdeka (UMUM)
('20000000-0001-4000-8000-000000000033', 'Drum Band WR Supratman 1 tampil di Lapangan Merdeka', 'Penampilan tim drumband kebanggaan sekolah di acara publik.', 'Penampilan tim drumband kebanggaan sekolah di acara publik.', 'activities/img_8060 copy.jpg', '2019-03-03 15:00:00', 'a3a02f83-0d81-48c6-9688-efc5b8c702f2'),
-- Kegiatan 34: Donor Darah Jan 2019 (UMUM)
('20000000-0001-4000-8000-000000000034', 'Kegiatan Donor Darah Perguruan WR Supratman 1 Januari 2019', 'Kegiatan sosial rutin tahunan untuk memenuhi kebutuhan darah PMI.', 'Kegiatan sosial rutin tahunan untuk memenuhi kebutuhan darah PMI.', 'activities/donor darah 2019 copy.jpg', '2019-01-25 08:30:00', 'a3a02f83-0d81-48c6-9688-efc5b8c702f2'),
-- Kegiatan 35: Motivasi Albert Masli (SMA)
('20000000-0001-4000-8000-000000000035', 'Motivasi Siswa SMA oleh Motivator Albert Masli', 'Seminar motivasi karir dan pendidikan oleh motivator profesional.', 'Seminar motivasi karir dan pendidikan oleh motivator profesional.', 'activities/seminar albert masli.jpg', '2019-10-15 10:00:00', 'a3a02f83-0d81-48c6-9688-efc5b8c702f2'),
-- Kegiatan 36: Outbound SMA (SMA)
('20000000-0001-4000-8000-000000000036', 'Outbound Training Siswa SMA', 'Pengembangan karakter, kepemimpinan, dan kerja sama tim melalui pelatihan luar ruangan.', 'Pengembangan karakter, kepemimpinan, dan kerja sama tim melalui pelatihan luar ruangan.', 'activities/dsc_9131 copy.jpg', '2025-11-10 07:00:00', 'a3a02f83-0d81-48c6-9688-efc5b8c702f2'),
-- Kegiatan 37: Mengunjungi Mantan Guru (UMUM)
('20000000-0001-4000-8000-000000000037', 'Mengunjungi Mantan Guru', 'Kunjungan silaturahmi perwakilan guru dan siswa kepada mantan guru yang telah pensiun.', 'Kunjungan silaturahmi perwakilan guru dan siswa kepada mantan guru yang telah pensiun.', 'activities/menjenguk ibu tjoa.jpg', '2019-02-05 14:00:00', 'a3a02f83-0d81-48c6-9688-efc5b8c702f2'),
-- Kegiatan 38: Bakti Sosial 2019 (UMUM)
('20000000-0001-4000-8000-000000000038', 'Perguruan WR Supratman 1 Mengadakan Bakti Sosial Menyambut Tahun Baru 2019', 'Kegiatan berbagi kasih menjelang pergantian tahun.', 'Kegiatan berbagi kasih menjelang pergantian tahun.', 'activities/img_9183 copy.jpg', '2018-12-28 09:00:00', 'a3a02f83-0d81-48c6-9688-efc5b8c702f2'),
-- Kegiatan 39: Lomba Pekan Bahasa (UMUM)
('20000000-0001-4000-8000-000000000039', 'Lomba Pekan Bahasa Virtual Menyambut Hari Pendidikan Nasional', 'Kompetisi pidato, puisi, dan esai bahasa secara virtual untuk mengasah kemampuan literasi.', 'Kompetisi pidato, puisi, dan esai bahasa secara virtual untuk mengasah kemampuan literasi.', 'activities/juara pekan bahasa sma copy copy.jpg', '2020-05-02 10:00:00', 'a3a02f83-0d81-48c6-9688-efc5b8c702f2'),
-- Kegiatan 40: Bakti Sosial Natal 2024 (UMUM)
('20000000-0001-4000-8000-000000000040', 'Bakti Sosial Menyambut Natal dan Tahun Baru 2024', 'Program amal tahunan menjelang libur akhir tahun.', 'Program amal tahunan menjelang libur akhir tahun.', 'activities/baksos2023a.png', '2023-12-20 08:30:00', 'a3a02f83-0d81-48c6-9688-efc5b8c702f2'),
-- Kegiatan 41: Perayaan Natal (UMUM)
('20000000-0001-4000-8000-000000000041', 'Kegiatan Perayaan Natal Desember 2023', 'Perayaan hari raya Natal oleh komunitas sekolah.', 'Perayaan hari raya Natal oleh komunitas sekolah.', 'activities/natal2023a.png', '2023-12-24 19:00:00', 'a3a02f83-0d81-48c6-9688-efc5b8c702f2'),
-- Kegiatan 42: Bimbingan Satlantas (UMUM)
('20000000-0001-4000-8000-000000000042', 'Bimbingan dan Pengarahan dari Satlantas', 'Edukasi keselamatan berlalu lintas dan etika berkendara kepada siswa oleh pihak Satlantas.', 'Edukasi keselamatan berlalu lintas dan etika berkendara kepada siswa oleh pihak Satlantas.', 'activities/upacara23a.png', '2024-01-10 07:30:00', 'a3a02f83-0d81-48c6-9688-efc5b8c702f2'),
-- Kegiatan 43: Pentas Seni Imlek (UMUM)
('20000000-0001-4000-8000-000000000043', 'Pentas Seni Festival Imlek 2575/2024', 'Acara pertunjukan seni dan budaya menyambut Tahun Baru Imlek.', 'Acara pertunjukan seni dan budaya menyambut Tahun Baru Imlek.', 'activities/imlek23a.jpg', '2025-02-05 18:00:00', 'a3a02f83-0d81-48c6-9688-efc5b8c702f2'),
-- Kegiatan 44: Studi Wisata Bangkok (SMA)
('20000000-0001-4000-8000-000000000044', 'Siswa-Siswi Studi Wisata ke Bangkok 2024', 'Kunjungan internasional untuk memperluas wawasan dan pengalaman budaya.', 'Kunjungan internasional untuk memperluas wawasan dan pengalaman budaya.', 'activities/bangkok 1 copy.png', '2024-06-01 06:00:00', 'a3a02f83-0d81-48c6-9688-efc5b8c702f2'),
-- Kegiatan 45: Diagnostic Test Kls XII (SMA)
('20000000-0001-4000-8000-000000000045', 'English Diagnostic Test sebagai salah satu syarat kelulusan siswa kelas XII', 'Ujian kemampuan Bahasa Inggris sebagai salah satu indikator dan syarat kelulusan.', 'Ujian kemampuan Bahasa Inggris sebagai salah satu indikator dan syarat kelulusan.', 'activities/diagnostic maret 2024 a.png', '2024-03-01 08:00:00', 'a3a02f83-0d81-48c6-9688-efc5b8c702f2'),
-- Kegiatan 46: Berbagi Takjil Gratis (UMUM)
('20000000-0001-4000-8000-000000000046', 'Kegiatan Berbagi Takjil Gratis', 'Aksi sosial pembagian makanan dan minuman berbuka puasa kepada masyarakat.', 'Aksi sosial pembagian makanan dan minuman berbuka puasa kepada masyarakat.', 'activities/takjil2024a.png', '2024-03-20 17:00:00', 'a3a02f83-0d81-48c6-9688-efc5b8c702f2'),
-- Kegiatan 47: Project Office Automation Kls 12 (SMA)
('20000000-0001-4000-8000-000000000047', 'Hasil karya Siswa kelas 12 Project Office Automation', 'Pameran hasil proyek otomatisasi perkantoran menggunakan teknologi digital.', 'Pameran hasil proyek otomatisasi perkantoran menggunakan teknologi digital.', 'activities/project kls12a.png', '2024-04-25 14:00:00', 'a3a02f83-0d81-48c6-9688-efc5b8c702f2'),
-- Kegiatan 48: Pawai MTQ (UMUM)
('20000000-0001-4000-8000-000000000048', 'Mengikuti Pawai Taaruf MTQ Ke 57 Kota Medan', 'Partisipasi dalam pawai pembukaan Musabaqah Tilawatil Quran tingkat kota.', 'Partisipasi dalam pawai pembukaan Musabaqah Tilawatil Quran tingkat kota.', 'activities/mtq24a.png', '2024-05-05 07:00:00', 'a3a02f83-0d81-48c6-9688-efc5b8c702f2'),
-- Kegiatan 49: Donor Darah Juni 2024 (UMUM)
('20000000-0001-4000-8000-000000000049', 'Kegiatan Donor Darah Juni 2024', 'Kegiatan donor darah rutin tahunan untuk meningkatkan ketersediaan darah.', 'Kegiatan donor darah rutin tahunan untuk meningkatkan ketersediaan darah.', 'activities/donor juni24 a.png', '2025-06-18 08:30:00', 'a3a02f83-0d81-48c6-9688-efc5b8c702f2'),
-- Kegiatan 50: Best Project TIK Kls X (SMA)
('20000000-0001-4000-8000-000000000050', 'Best Project TIK Kelas X Edisi Juni 2024', 'Pameran dan penilaian proyek-proyek terbaik TIK siswa kelas X.', 'Pameran dan penilaian proyek-proyek terbaik TIK siswa kelas X.', 'activities/tikjuni24a.png', '2024-06-15 14:00:00', 'a3a02f83-0d81-48c6-9688-efc5b8c702f2'),
-- Kegiatan 51: Best Project TIK Kls XI (SMA)
('20000000-0001-4000-8000-000000000051', 'Best Project TIK Kelas XI Edisi Juni 2024', 'Pameran dan penilaian proyek-proyek terbaik TIK siswa kelas XI.', 'Pameran dan penilaian proyek-proyek terbaik TIK siswa kelas XI.', 'activities/tikjuni11a.png', '2024-06-16 14:00:00', 'a3a02f83-0d81-48c6-9688-efc5b8c702f2'),
-- Kegiatan 52: Penyerahan Trophy (UMUM)
('20000000-0001-4000-8000-000000000052', 'Penyerahan Trophy dan Beasiswa kepada Siswa Berprestasi', 'Acara penghargaan bagi siswa dengan prestasi akademik dan non-akademik.', 'Acara penghargaan bagi siswa dengan prestasi akademik dan non-akademik.', 'activities/beasiswa24b.jpg', '2025-01-08 10:00:00', 'a3a02f83-0d81-48c6-9688-efc5b8c702f2'),
-- Kegiatan 53: Seminar Hukum (UMUM)
('20000000-0001-4000-8000-000000000053', 'Seminar Kesadaran Hukum', 'Edukasi mengenai pentingnya kesadaran hukum dan bahaya kenakalan remaja.', 'Edukasi mengenai pentingnya kesadaran hukum dan bahaya kenakalan remaja.', 'activities/hukuma.jpg', '2024-08-05 09:30:00', 'a3a02f83-0d81-48c6-9688-efc5b8c702f2'),
-- Kegiatan 54: Education Expo (SMA)
('20000000-0001-4000-8000-000000000054', 'Education Expo 2024', 'Pameran pendidikan tinggi dan karir untuk memberikan wawasan kepada siswa SMA.', 'Pameran pendidikan tinggi dan karir untuk memberikan wawasan kepada siswa SMA.', 'activities/expo24a.jpg', '2025-03-10 09:00:00', 'a3a02f83-0d81-48c6-9688-efc5b8c702f2'),
-- Kegiatan 55: Workshop Merakit PC (SMA)
('20000000-0001-4000-8000-000000000055', 'Workshop Merakit PC', 'Pelatihan praktis perakitan komputer dan instalasi sistem operasi. Wajib diikuti oleh siswa TIK.', 'Pelatihan praktis perakitan komputer dan instalasi sistem operasi. Wajib diikuti oleh siswa TIK.', 'activities/rakit 1.jpg', '2025-10-01 13:00:00', 'a3a02f83-0d81-48c6-9688-efc5b8c702f2')

ON CONFLICT (kegiatan_id) DO NOTHING;

COMMIT;


BEGIN;

INSERT INTO "kegiatan_jenjang" (kegiatan_id, jenjang_id) VALUES
-- PGTK (b1b820d5-2714-41ee-a8e2-4da7714da164):
('20000000-0001-4000-8000-000000000032', 'b1b820d5-2714-41ee-a8e2-4da7714da164'), -- Parade Drumband
('20000000-0001-4000-8000-000000000033', 'b1b820d5-2714-41ee-a8e2-4da7714da164'), -- Drumband Lapangan Merdeka

-- SD (f8d1bb69-4839-4b13-977e-d21671e546f5):
('20000000-0001-4000-8000-000000000029', 'f8d1bb69-4839-4b13-977e-d21671e546f5'), -- Kunjungan Harian Analisa
('20000000-0001-4000-8000-000000000032', 'f8d1bb69-4839-4b13-977e-d21671e546f5'), -- Parade Drumband

-- SMP (bbbd1c32-72e8-4710-b209-e1503a9250eb):
('20000000-0001-4000-8000-000000000027', 'bbbd1c32-72e8-4710-b209-e1503a9250eb'), -- Malam Kenangan
('20000000-0001-4000-8000-000000000029', 'bbbd1c32-72e8-4710-b209-e1503a9250eb'), -- Kunjungan Harian Analisa

-- SMA (0c09118b-be66-4f04-aaf0-a15e77aa870a):
('20000000-0001-4000-8000-000000000001', '0c09118b-be66-4f04-aaf0-a15e77aa870a'), -- Lomba Cipta Boga
('20000000-0001-4000-8000-000000000005', '0c09118b-be66-4f04-aaf0-a15e77aa870a'), -- Lomba TIK SMA
('20000000-0001-4000-8000-000000000009', '0c09118b-be66-4f04-aaf0-a15e77aa870a'), -- Tanoto Gathering
('20000000-0001-4000-8000-000000000010', '0c09118b-be66-4f04-aaf0-a15e77aa870a'), -- Seminar HPV
('20000000-0001-4000-8000-000000000011', '0c09118b-be66-4f04-aaf0-a15e77aa870a'), -- Seminar Bisnis
('20000000-0001-4000-8000-000000000013', '0c09118b-be66-4f04-aaf0-a15e77aa870a'), -- Outbound Kls 12
('20000000-0001-4000-8000-000000000015', '0c09118b-be66-4f04-aaf0-a15e77aa870a'), -- Best Project Kls X
('20000000-0001-4000-8000-000000000016', '0c09118b-be66-4f04-aaf0-a15e77aa870a'), -- Best Project Kls XI
('20000000-0001-4000-8000-000000000018', '0c09118b-be66-4f04-aaf0-a15e77aa870a'), -- Kunjungan RGE Career
('20000000-0001-4000-8000-000000000020', '0c09118b-be66-4f04-aaf0-a15e77aa870a'), -- Perekaman E-KTP
('20000000-0001-4000-8000-000000000025', '0c09118b-be66-4f04-aaf0-a15e77aa870a'), -- Business Plan UNPRI
('20000000-0001-4000-8000-000000000027', '0c09118b-be66-4f04-aaf0-a15e77aa870a'), -- Malam Kenangan
('20000000-0001-4000-8000-000000000035', '0c09118b-be66-4f04-aaf0-a15e77aa870a'), -- Motivasi Albert Masli
('20000000-0001-4000-8000-000000000036', '0c09118b-be66-4f04-aaf0-a15e77aa870a'), -- Outbound SMA
('20000000-0001-4000-8000-000000000044', '0c09118b-be66-4f04-aaf0-a15e77aa870a'), -- Studi Wisata Bangkok
('20000000-0001-4000-8000-000000000045', '0c09118b-be66-4f04-aaf0-a15e77aa870a'), -- Diagnostic Test Kls XII
('20000000-0001-4000-8000-000000000047', '0c09118b-be66-4f04-aaf0-a15e77aa870a'), -- Project Office Automation
('20000000-0001-4000-8000-000000000050', '0c09118b-be66-4f04-aaf0-a15e77aa870a'), -- Best Project TIK Kls X
('20000000-0001-4000-8000-000000000051', '0c09118b-be66-4f04-aaf0-a15e77aa870a'), -- Best Project TIK Kls XI
('20000000-0001-4000-8000-000000000054', '0c09118b-be66-4f04-aaf0-a15e77aa870a'), -- Education Expo
('20000000-0001-4000-8000-000000000055', '0c09118b-be66-4f04-aaf0-a15e77aa870a'), -- Workshop Merakit PC

-- Kelompok UMUM (Setiap jenjang berpartisipasi di kegiatan ini, kecuali dinyatakan spesifik)
-- Kegiatan 2 (Bazar), 3 (TIK Virtual), 4 (PSB), 6 (Studi Wisata), 7 (Prakarya), 8 (Donor Darah), 12 (Takjil), 14 (Waisak), 17 (Cybercrime), 19 (Tzu Chi), 21 (Keuangan), 22 (Talent Mapping), 23 (Baksos 2022), 24 (Jalan Sehat), 26 (Kunjungan Indofood), 28 (Motivasi), 29 (Analisa), 30 (BI), 31 (Gerak Jalan), 32 (Drumband), 33 (Drumband Merdeka), 34 (Donor Darah 2019), 37 (Guru), 38 (Baksos 2019), 39 (Pekan Bahasa), 40 (Baksos Natal), 41 (Natal), 42 (Satlantas), 43 (Imlek), 46 (Takjil Gratis), 48 (MTQ), 49 (Donor Darah Juni), 52 (Trophy), 53 (Seminar Hukum).

-- Contoh untuk Kegiatan 2 (Bazar) yang Umum:
('20000000-0001-4000-8000-000000000002', 'b1b820d5-2714-41ee-a8e2-4da7714da164'), -- PGTK
('20000000-0001-4000-8000-000000000002', 'f8d1bb69-4839-4b13-977e-d21671e546f5'), -- SD
('20000000-0001-4000-8000-000000000002', 'bbbd1c32-72e8-4710-b209-e1503a9250eb'), -- SMP
('20000000-0001-4000-8000-000000000002', '0c09118b-be66-4f04-aaf0-a15e77aa870a'), -- SMA

-- KODE INI AKAN SANGAT PANJANG, JADI SAYA HANYA BERIKAN BEBERAPA CONTOH LAGI:

-- Contoh untuk Kegiatan 3 (Lomba TIK Virtual)
('20000000-0001-4000-8000-000000000003', 'f8d1bb69-4839-4b13-977e-d21671e546f5'), -- SD
('20000000-0001-4000-8000-000000000003', 'bbbd1c32-72e8-4710-b209-e1503a9250eb'), -- SMP
('20000000-0001-4000-8000-000000000003', '0c09118b-be66-4f04-aaf0-a15e77aa870a'), -- SMA

-- Contoh untuk Kegiatan 27 (Malam Kenangan)
('20000000-0001-4000-8000-000000000027', 'bbbd1c32-72e8-4710-b209-e1503a9250eb'), -- SMP
('20000000-0001-4000-8000-000000000027', '0c09118b-be66-4f04-aaf0-a15e77aa870a') -- SMA

-- Anda harus mengulang pasangan (kegiatan_id, jenjang_id) ini untuk SEMUA 40 kegiatan.

ON CONFLICT DO NOTHING;

COMMIT;